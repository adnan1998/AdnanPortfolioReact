export default function Services() {
    return (
        <div className="services">
            <h1 className="serviceHeading">MY SERVICES</h1>
            <div className="servicesContainer">
                <div className="service blue">1</div>
                <div className="service orange">2</div>
                <div className="service red">3</div>
                <div className="service purple">4</div>
                <div className="service green">5</div>
                <div className="service lavender">6</div>
            </div>
        </div>
    );
}
// Web designing
// Web development
// SEO
// UI UX design
// API integration
//

